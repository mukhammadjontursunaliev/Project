# app/models.py

from pydantic import BaseModel
from typing import List

class Flow(BaseModel):
    flow_duration: float
    totlen_fwd_pkts: int
    totlen_bwd_pkts: int
    src_port: int
    dst_port: int

class FlowList(BaseModel):
    flows: List[Flow]
