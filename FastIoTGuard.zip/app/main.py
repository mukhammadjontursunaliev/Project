# app/main.py

from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from typing import List
from pathlib import Path
import joblib
import numpy as np

# 1. Initialize app & paths
app = FastAPI()
BASE_DIR = Path(__file__).resolve().parent
ARTIFACTS = BASE_DIR.parent / "artifacts"  # adjust if your artifacts live elsewhere

# 2. Mount static files (CSS/JS)
app.mount(
    "/static",
    StaticFiles(directory=BASE_DIR / "static"),
    name="static"
)

# 3. Configure Jinja2 templates
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

# 4. Load ML artifacts
model = joblib.load(str(ARTIFACTS / "model.joblib"))
scaler = joblib.load(str(ARTIFACTS / "scaler.joblib"))
label_encoder = joblib.load(str(ARTIFACTS / "label_encoder.joblib"))


# 5. Pydantic schemas for input validation
class Flow(BaseModel):
    flow_duration: float
    totlen_fwd_pkts: int
    totlen_bwd_pkts: int
    src_port: int
    dst_port: int


class FlowList(BaseModel):
    flows: List[Flow]


# 6. GET "/" → render the input form
@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


# 7. POST "/process" → parse, score, and visualize
@app.post("/process", response_class=HTMLResponse)
async def process(request: Request, payload: str = Form(...)):
    # 1. Parse & validate
    flow_list = FlowList.parse_raw(payload)

    # 2. Build feature matrix
    X = np.array([
        [f.flow_duration, f.totlen_fwd_pkts, f.totlen_bwd_pkts, f.src_port, f.dst_port]
        for f in flow_list.flows
    ])

    # 3. Scale & predict
    X_scaled   = scaler.transform(X)
    raw_scores = model.decision_function(X_scaled)
    preds      = model.predict(X_scaled)
    norm_scores = ((raw_scores - raw_scores.min()) / (raw_scores.max() - raw_scores.min()) * 100).round(1)

    # 4. Build flow_results list
    flow_results = []
    for i, (score, pred) in enumerate(zip(norm_scores, preds), start=1):
        label = "Normal" if pred == 1 else "Anomalous"
        if label == "Anomalous":
            reason = "High packet count or duration"
        else:
            reason = "Within normal behavior"
        flow_results.append({
            "index": i,
            "score": score,
            "label": label,
            "reason": reason
        })

    total_flows = len(flow_results)
    anomaly_pct = round(sum(1 for fr in flow_results if fr["label"]=="Anomalous") / total_flows * 100, 1)

    # 5. Render template
    return templates.TemplateResponse("result.html", {
        "request":       request,
        "flow_results":  flow_results,
        "total_flows":   total_flows,
        "anomaly_pct":   anomaly_pct,
    })