# FastIoTGuard

**FastIoTGuard** is a lightweight web application for real-time IoT flow anomaly detection. It combines a pretrained scikit-learn model with a modern FastAPI + Jinja2 front end, styled with Bootstrap and visualized via Chart.js. Users paste JSON-formatted flow records, and get an interactive line chart, summary statistics, and detailed per-flow results.

---

## Table of Contents

1. [Features](#features)  
2. [Architecture](#architecture)  
3. [Getting Started](#getting-started)  
   1. [Prerequisites](#prerequisites)  
   2. [Installation](#installation)  
   3. [Running the App](#running-the-app)  
4. [Usage](#usage)  
   1. [Input Format](#input-format)  
   2. [Endpoints](#endpoints)  
5. [Project Structure](#project-structure)  
6. [Development Guidelines](#development-guidelines)  
7. [Extending & Updating the Model](#extending--updating-the-model)  
8. [Testing](#testing)  
9. [Deployment](#deployment)  
10. [Contributing](#contributing)  
11. [License](#license)  

---

## Features

- **Real-time inference** of IoT flow anomalies using a pretrained IsolationForest  
- **Interactive dashboard**: line chart of anomaly scores, colored points, tooltips  
- **Responsive UI** built with Bootstrap 5 and custom CSS  
- **Server-side HTML** via FastAPI + Jinja2 templates  
- **JSON validation** with Pydantic schemas  
- **Detailed table** of per-flow scores, labels, and heuristic explanations  

---

## Architecture



---

## Getting Started

### Prerequisites

- **Python 3.8+**  
- **pip** (or **poetry** / **pipenv**)  
- (Optional) **virtualenv** or **venv**  

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-org/FastIoTGuard.git
   cd FastIoTGuard
